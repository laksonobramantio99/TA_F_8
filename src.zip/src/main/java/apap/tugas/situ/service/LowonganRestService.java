package apap.tugas.situ.service;

import apap.tugas.situ.rest.UserSiperpusDetail;

import java.util.List;
import java.util.Map;

public interface LowonganRestService {
    List<Map> getListUserSiperpus();
}
