package apap.tugas.situ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SituApplication {

	public static void main(String[] args) {
		SpringApplication.run(SituApplication.class, args);
	}

}
