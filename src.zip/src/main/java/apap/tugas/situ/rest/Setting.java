package apap.tugas.situ.rest;

public class Setting {
    final public static String getSivitas = "http://sivitas.herokuapp.com/api/";
    final public static String suratUrl= "https://6fd1435b-96b2-486d-85d9-31abe4cdfacc.mock.pstmn.io";
    final public static String listUserUrl = "https://6b3f7bf0-2af2-41d4-93ea-9b922964d450.mock.pstmn.io";
    final public static String listUserSiperpus = "https://9a8a766c-8425-40aa-8883-1b7de195287f.mock.pstmn.io";
}
